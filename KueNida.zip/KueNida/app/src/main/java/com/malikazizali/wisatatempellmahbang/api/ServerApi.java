package com.malikazizali.wisatatempellmahbang.api;

public class ServerApi {

    public static final String URL_Register = "https://royalweaboo.000webhostapp.com/uas/register.php";
    public static final String URL_Login = "https://royalweaboo.000webhostapp.com/uas/login.php";
    public static final String URL_Fetch = "https://royalweaboo.000webhostapp.com/uas/getData.php";
    public static final String URL_Fetch_History = "https://royalweaboo.000webhostapp.com/uas/getHistory.php";
    public static final String URL_Save_History = "https://royalweaboo.000webhostapp.com/uas/tambahHistory.php";
    public static final String URL_Update_Pass = "https://royalweaboo.000webhostapp.com/uas/updatePassword.php";
    public static final String URL_Update_Status = "https://royalweaboo.000webhostapp.com/uas/updateStatus.php";

}
