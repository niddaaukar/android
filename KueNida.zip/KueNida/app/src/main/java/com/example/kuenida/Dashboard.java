package com.example.kuenida;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.RecyclerView;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Dashboard extends AppCompatActivity implements RecycleViewAdapter.OnNoteListener {

    private static final int REQUEST_CALL = 1;

    RecyclerView recyclerView;
    ArrayList<Model> dataPaket = new ArrayList<>();
    RecycleViewAdapter recycleViewAdapter;

    int total_harga_int;
    LinearLayout checkout;

    Dialog dialog;
    TextView total_harga, textView_total, totalHarga_dialog, totalKembalian_dialog, textView_kembalian;
    EditText payment_dialog;
    Button btn_bayar, btn_cancel, btn_hitung;
    String biaya, logged_user, st;
    FloatingActionButton fab;
    SharedPreferences sp,sph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        checkout = findViewById(R.id.checkout);
        total_harga = findViewById(R.id.total_harga);
        recyclerView = findViewById(R.id.rv_main);
        recycleViewAdapter = new RecycleViewAdapter(dataPaket, Dashboard.this, this);
        recyclerView.setAdapter(recycleViewAdapter);
        textView_total = findViewById(R.id.tv_total);
        sp = getSharedPreferences("totalBiaya", MODE_PRIVATE);
        sph = getSharedPreferences("saveHistory", MODE_PRIVATE);
        st = sp.getString("savedTotal", "");
        total_harga.setText(st);
        fab = findViewById(R.id.fab_reset);
        //GetData();

        checkout = findViewById(R.id.checkout);
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (total_harga_int == 0) {
                    Toast.makeText(Dashboard.this, "Anda belum memilih paket apapun", Toast.LENGTH_SHORT).show();
                } else {
                    dialog.show();
                    totalHarga_dialog.setVisibility(View.VISIBLE);
                    totalHarga_dialog.setText("Rp. " + total_harga_int);
                }
            }
        });


    };