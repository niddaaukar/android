package com.example.kalkulatornida;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class Persegi extends AppCompatActivity {
    private EditText sisi;
    private TextView hasilLuasPersegi;
    private TextView hasilKelilingPersegi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);
        sisi = (EditText) findViewById(R.id.sisi);
        hasilKelilingPersegi = (TextView)
                findViewById(R.id.TVKelilingPersegi);
        hasilLuasPersegi = (TextView) findViewById(R.id.TVLuasPersegi);
    }
    public void LuasPersegi(View view) {
        int s = Integer.parseInt(sisi.getText().toString());
        int luas = s * s;
        hasilLuasPersegi.setText(String.valueOf(luas));
    }
    public void KelilingPersegi(View view) {
        int s = Integer.parseInt(sisi.getText().toString());
        int keliling = 4 * s;
        hasilKelilingPersegi.setText(String.valueOf(keliling));
    }
}
