package com.example.kalkulatornida;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class Kubus extends AppCompatActivity {
    private EditText rusuk;
    private TextView hasilLuasPermukaanKubus;
    private TextView hasilKelilingKubus;
    private TextView hasilVolumeKubus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kubus);
        rusuk = (EditText) findViewById(R.id.rusuk);
        hasilKelilingKubus = (TextView) findViewById(R.id.TVKelilingKubus);
        hasilLuasPermukaanKubus = (TextView)
                findViewById(R.id.TVLuasKubus);
        hasilVolumeKubus = (TextView) findViewById(R.id.TVVolumeKubus);
    }
    public void LuasPermukaanKubus(View view) {
        int s = Integer.parseInt(rusuk.getText().toString());
        int luas = 6 * (s * s);
        hasilLuasPermukaanKubus.setText(String.valueOf(luas));
    }
    public void KelilingKubus(View view) {
        int s = Integer.parseInt(rusuk.getText().toString());
        int keliling = 12 * s;
        hasilKelilingKubus.setText(String.valueOf(keliling));
    }
    public void VolumeKubus(View view) {
        int s = Integer.parseInt(rusuk.getText().toString());
        int volume = s * s * s;
        hasilVolumeKubus.setText(String.valueOf(volume));
    }
}
